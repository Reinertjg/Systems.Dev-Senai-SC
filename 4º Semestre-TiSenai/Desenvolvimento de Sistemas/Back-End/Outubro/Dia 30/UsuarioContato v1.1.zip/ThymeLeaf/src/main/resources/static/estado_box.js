function atualizarSigla() {
        const selectEstado = document.getElementById('nome');
        const inputSigla = document.getElementById('Sigla');
        inputSigla.value = selectEstado.value; // Atualiza o input com a sigla do estado selecionado
    }