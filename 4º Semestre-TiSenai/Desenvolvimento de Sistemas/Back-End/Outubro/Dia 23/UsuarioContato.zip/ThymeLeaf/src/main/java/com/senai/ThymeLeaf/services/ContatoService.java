package com.senai.ThymeLeaf.services;

import com.senai.ThymeLeaf.dtos.CadastroContatoDto;
import com.senai.ThymeLeaf.dtos.ContatoDto;
import com.senai.ThymeLeaf.models.ContatoModel;
import com.senai.ThymeLeaf.repositories.ContatoRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ContatoService {

    @Autowired
    ContatoRepository contatorepository;

    public List<ContatoDto> obterListaContato() {

        List<ContatoModel> listaContatoModel = contatorepository.findAll();

        List<ContatoDto> listaContato = new ArrayList();

        for (ContatoModel contato : listaContatoModel) {

            ContatoDto contatoDto = new ContatoDto();
            contatoDto.setId(contato.getId());
            contatoDto.setNome(contato.getNome());
            contatoDto.setTelefone(contato.getTelefone());
            contatoDto.setEmail(contato.getEmail());
            contatoDto.setEndereco(contato.getEndereco());
            contatoDto.setCpf(contato.getCpf());

            listaContato.add(contatoDto);
        }

        return listaContato;
    }

    public boolean cadastrarContato(CadastroContatoDto cadastro) {

        Optional<ContatoModel> optionalContato = contatorepository.findByEmail(cadastro.getEmail());

        if (optionalContato.isPresent()) {
            return false;
        }

        ContatoModel contatoModel = new ContatoModel();
        contatoModel.setNome(cadastro.getNome());
        contatoModel.setTelefone(cadastro.getTelefone());
        contatoModel.setEmail(cadastro.getEmail());
        contatoModel.setEndereco(cadastro.getEndereco());
        contatoModel.setCpf(cadastro.getCpf());

        contatorepository.save(contatoModel);
        
        return true;
    }
    
    public boolean excluirContato(Long id){
        
        System.out.println("id:" + id);
        
        Optional<ContatoModel> optionalContato = contatorepository.findById(id);
        
        if (!optionalContato.isPresent()){
            return false;
        }
        
        contatorepository.delete(optionalContato.get());
        
        return true;
    }
    
    
    public ContatoDto obterContato(Long id){
        
        Optional<ContatoModel> optionalContato = contatorepository.findById(id);
        
        ContatoDto contatoDto = new ContatoDto();
        
        if(!optionalContato.isPresent()){
            contatoDto.setId(0L);
            return contatoDto;
        }
        
        contatoDto.setId(optionalContato.get().getId());
        contatoDto.setNome(optionalContato.get().getNome());
        contatoDto.setTelefone(optionalContato.get().getTelefone());
        contatoDto.setEmail(optionalContato.get().getEmail());
        contatoDto.setEndereco(optionalContato.get().getEndereco());
        contatoDto.setCpf(optionalContato.get().getCpf());
        
        return contatoDto;
    }
}
