
package com.senai.calculadora.dtos;

public class CalculadoraDTO {
    
    private float numero1;
    private float numero2;

    public CalculadoraDTO() {
    }

    public float getNumero1() {
        return numero1;
    }

    public void setNumero1(float numero1) {
        this.numero1 = numero1;
    }

    public float getNumero2() {
        return numero2;
    }

    public void setNumero2(float numero2) {
        this.numero2 = numero2;
    }
    
    
    
}
