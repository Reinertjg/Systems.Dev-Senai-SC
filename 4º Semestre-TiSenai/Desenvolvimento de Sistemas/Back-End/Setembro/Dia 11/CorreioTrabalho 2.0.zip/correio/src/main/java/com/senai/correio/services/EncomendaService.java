package com.senai.correio.services;

import com.senai.correio.dtos.*;
import com.senai.correio.models.*;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EncomendaService {
    
    @Autowired
    DestinatarioService servico;

    ArrayList<EncomendaModel> encomendaLista = new ArrayList<>();

    public boolean cadastrar(EncomendaDto dados) {

        boolean valido = true;

        for (EncomendaModel enc : encomendaLista) {

            if (enc.getId().equals(dados.getId())) {
                valido = false;
            }
        }

        if (valido) {
            EncomendaModel encomenda = new EncomendaModel();
            encomenda.setId(dados.getId());
            encomenda.setNome(dados.getNome());
            encomenda.setDescricao(dados.getDescricao());
            encomenda.setPeso(dados.getPeso());
            encomenda.setDestinatarioId(dados.getDestinatarioId());

            encomendaLista.add(encomenda);
            valido = true;
        }
        return valido;

    }

    public boolean atualizar(EncomendaDto dados) {

        boolean valido = false;
        
        for (EncomendaModel enc : encomendaLista) {

            if (enc.getId().equals(dados.getId())) {

                enc.setId(dados.getId());
                enc.setNome(dados.getNome());
                enc.setDescricao(dados.getDescricao());
                enc.setPeso(dados.getPeso());
                enc.setDestinatarioId(dados.getDestinatarioId());

                valido = true;
            }
        }
        return valido;
    }

    public ArrayList<EncomendaDto> obter() {

        ArrayList<EncomendaDto> listaDto = new ArrayList<>();

        for (EncomendaModel enc : encomendaLista) {

            EncomendaDto encDto = new EncomendaDto();
            encDto.setId(enc.getId());
            encDto.setNome(enc.getNome());
            encDto.setDescricao(enc.getDescricao());
            encDto.setPeso(enc.getPeso());
            encDto.setDestinatarioId(enc.getDestinatarioId());

            listaDto.add(encDto);
        }

        return listaDto;
    }

}
