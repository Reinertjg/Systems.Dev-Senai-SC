package com.senai.correio.controllers;

import com.senai.correio.dtos.*;
import com.senai.correio.models.*;
import com.senai.correio.services.*;
import jakarta.validation.Valid;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/encomenda")
@Validated
public class EncomendaController {

    @Autowired
    EncomendaService servico;

    @PostMapping
    public ResponseEntity<RespostaCadastroDto> cadastrar(@Valid @RequestBody EncomendaDto dados) {

        boolean retorno = servico.cadastrar(dados);

        RespostaCadastroDto resposta = new RespostaCadastroDto();

        if (retorno) {
            resposta.setResposta("Cadastro realizado com sucesso!");
            return ResponseEntity.status(HttpStatus.OK).body(resposta);
        } else {
            resposta.setResposta("Erro, ID ja cadastrado!");
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(resposta);
        }

    }

    @PutMapping
    public ResponseEntity<RespostaCadastroDto> atualizar(@Valid @RequestBody EncomendaDto dados) {

        boolean retorno = servico.atualizar(dados);

        RespostaCadastroDto resposta = new RespostaCadastroDto();

        if (retorno) {
            resposta.setResposta("Encomenda atualizado com sucesso!");
            return ResponseEntity.status(HttpStatus.OK).body(resposta);
        } else {
            resposta.setResposta("Erro ao encontrar o Encomenda!");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);
        }

    }

    @GetMapping
    public ArrayList obter() {

        ArrayList retorno = servico.obter();

        return retorno;
    }

}
