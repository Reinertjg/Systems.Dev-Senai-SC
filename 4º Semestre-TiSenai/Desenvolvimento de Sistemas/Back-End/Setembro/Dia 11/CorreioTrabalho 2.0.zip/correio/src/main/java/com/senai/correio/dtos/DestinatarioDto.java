
package com.senai.correio.dtos;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;


public class DestinatarioDto {
    
    @NotNull(message = "O ID é obrigatório")
    @Size (min = 3, max = 6, message = "O ID deve ter entre 3 e 6 caracteres")
    private String id;
    
    @NotNull(message = "O nome é obrigatório")
    @Size (min = 3, max = 50, message = "O nome deve ter entre 3 e 50 caracteres")
    private String nome;
    
    @NotNull(message = "O endereco é obrigatório")
    @Size (min = 3, max = 50, message = "O endereco deve ter entre 3 e 50 caracteres")
    private String endereco;
    
    @NotNull(message = "O telefone é obrigatório")
    @Size (min = 11, max = 13, message = "O endereco deve ter entre 11 e 13 caracteres")
    private String telefone;

    public DestinatarioDto() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
    
}
