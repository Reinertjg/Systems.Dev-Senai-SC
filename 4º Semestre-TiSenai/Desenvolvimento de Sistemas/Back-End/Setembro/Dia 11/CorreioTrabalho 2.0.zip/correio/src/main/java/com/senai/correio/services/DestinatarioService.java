package com.senai.correio.services;

import com.senai.correio.dtos.DestinatarioDto;
import com.senai.correio.dtos.RespostaCadastroDto;
import com.senai.correio.models.DestinatarioModel;
import java.util.ArrayList;
import org.springframework.stereotype.Service;

@Service
public class DestinatarioService {

    ArrayList<DestinatarioModel> destinatarioLista = new ArrayList<>();

    public boolean cadastrar(DestinatarioDto dados) {

        boolean valido = true;

        for (DestinatarioModel des : destinatarioLista) {

            if (des.getId().equals(dados.getId())) {
                valido = false;
            }
        }

        if (valido) {
            DestinatarioModel destinatario = new DestinatarioModel();
            destinatario.setId(dados.getId());
            destinatario.setNome(dados.getNome());
            destinatario.setEndereco(dados.getEndereco());
            destinatario.setTelefone(dados.getTelefone());

            destinatarioLista.add(destinatario);
            valido = true;
        }
        return valido;

    }

    public boolean atualizar(DestinatarioDto dados) {

        boolean valido = false;

        for (DestinatarioModel des : destinatarioLista) {

            if (des.getId().equals(dados.getId())) {

                des.setId(dados.getId());
                des.setNome(dados.getNome());
                des.setEndereco(dados.getEndereco());
                des.setTelefone(dados.getTelefone());

                valido = true;
            }
        }
        return valido;
    }

    public ArrayList<DestinatarioDto> obter() {

        ArrayList<DestinatarioDto> listaDto = new ArrayList<>();

        for (DestinatarioModel des : destinatarioLista) {

            DestinatarioDto desDto = new DestinatarioDto();
            desDto.setId(des.getId());
            desDto.setNome(des.getNome());
            desDto.setEndereco(des.getEndereco());
            desDto.setTelefone(des.getTelefone());

            listaDto.add(desDto);
        }

        return listaDto;
    }

}
