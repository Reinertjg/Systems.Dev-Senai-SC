package com.senai.correio.dtos;

public class RespostaCadastroDto {
    
    private String resposta;

    public RespostaCadastroDto() {
    }

    public String getResposta() {
        return resposta;
    }

    public void setResposta(String resposta) {
        this.resposta = resposta;
    }
    
}
