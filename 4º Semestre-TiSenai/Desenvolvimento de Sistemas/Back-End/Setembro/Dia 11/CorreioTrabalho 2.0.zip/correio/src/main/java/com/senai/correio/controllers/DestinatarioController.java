package com.senai.correio.controllers;

import com.senai.correio.dtos.*;
import com.senai.correio.models.DestinatarioModel;
import com.senai.correio.services.*;
import jakarta.validation.Valid;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/destinatario")
@Validated
public class DestinatarioController {

    @Autowired
    DestinatarioService servico;

    @PostMapping
    public ResponseEntity<RespostaCadastroDto> cadastrar(@Valid @RequestBody DestinatarioDto dados) {

        boolean retorno = servico.cadastrar(dados);

        RespostaCadastroDto resposta = new RespostaCadastroDto();

        if (retorno) {
            resposta.setResposta("Cadastro realizado com sucesso!");
            return ResponseEntity.status(HttpStatus.OK).body(resposta);
        } else {
            resposta.setResposta("Erro, ID ja cadastrado!");
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(resposta);
        }

    }

    @PutMapping
    public ResponseEntity<RespostaCadastroDto> atualizar(@Valid @RequestBody DestinatarioDto dados) {

        boolean retorno = servico.atualizar(dados);

        RespostaCadastroDto resposta = new RespostaCadastroDto();

        if (retorno) {
            resposta.setResposta("Destinatario atualizado com sucesso!");
            return ResponseEntity.status(HttpStatus.OK).body(resposta);
        } else {
            resposta.setResposta("Erro ao encontrar o Destinatario!");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resposta);
        }

    }

    @GetMapping
    public ArrayList obter() {

        ArrayList retorno = servico.obter();

        return retorno;
    }

}
