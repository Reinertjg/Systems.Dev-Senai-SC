
package com.senai.correio.dtos;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class EncomendaDto {
    
    @NotNull(message = "O ID é obrigatório")
    @Size (min = 3, max = 6, message = "O ID deve ter entre 3 e 6 caracteres")
    private String id;
    
    @NotNull(message = "O nome é obrigatório")
    @Size (min = 3, max = 50, message = "O nome deve ter entre 3 e 50 caracteres")
    private String nome;
    
    @NotNull(message = "O descricao é obrigatório")
    @Size (min = 3, max = 50, message = "O descricao deve ter entre 3 e 50 caracteres")
    private String descricao;
    
    @NotNull(message = "O peso é obrigatório")
    @Size (min = 1, max = 50, message = "O peso deve ter entre 1 e 50 caracteres")
    private float peso;
    
    @NotNull(message = "O destinatarioId é obrigatório")
    @Size (min = 3, max = 6, message = "O destinatarioId deve ter entre 3 e 6 caracteres")
    private String destinatarioId;

    public EncomendaDto() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public String getDestinatarioId() {
        return destinatarioId;
    }

    public void setDestinatarioId(String destinatarioId) {
        this.destinatarioId = destinatarioId;
    }
    
}
