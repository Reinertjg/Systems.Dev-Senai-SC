package com.senai.ThymeLeaf.dtos;

import lombok.Data;

@Data
public class UsuarioDto {

    private Long id;

    private String email;

    private String nome;
    
}
