package com.senai.ThymeLeaf.dtos;

import lombok.Data;

@Data
public class EstadoDto {

    private String sigla;
            
    private String nome;
    
}
