package com.senai.ThymeLeaf.dtos;

import lombok.Data;

@Data
public class CadastroDto {

    private String nome;
   
    private String email;
    
    private String senha;
}
