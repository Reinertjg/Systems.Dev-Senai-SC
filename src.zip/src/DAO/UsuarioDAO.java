package DAO;

import Conexao.ModuloConexao;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import Entity.Clientes;
import com.mysql.cj.jdbc.PreparedStatementWrapper;

public class UsuarioDAO {
    
    
    public void cadastrarUsuario(Clientes clientes){
        
        String sql = "INSERT INTO CLIENTES (LOGIN, SENHA) VALUES (?, ?)";
        
        PreparedStatement ps = null;
        
        try {
            ps = ModuloConexao.conector().prepareStatement(sql);
            ps.setString(1, clientes.getLogin());
            ps.setString(2, clientes.getSenha());
            
            ps.execute();
            ps.close();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
    }
}
