package DAO;

import Conexao.ModuloConexao;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import Entity.Tarefas;
import com.mysql.cj.jdbc.PreparedStatementWrapper;

public class TarefaDAO {
    
    
    public void cadastrarTarefa(Tarefas tarefas){
        
        String sql = "INSERT INTO TAREFAS (NOMETAREFA, DESCRICAOTAREFA, DATAVENCIMENTOTAREFA, USUARIOTAREFA) VALUES (?, ?, ?, ?)";
        
        PreparedStatement ps = null;
        
        try {
            ps = ModuloConexao.conector().prepareStatement(sql);
            ps.setString(1, tarefas.getNomeTarefa());
            ps.setString(2, tarefas.getDescricaoTarefa());
            ps.setString(3, tarefas.getDataVencimentoTarefa());
            ps.setString(4, tarefas.getUsuarioTarefa());
            
            ps.execute();
            ps.close();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
    }
}
