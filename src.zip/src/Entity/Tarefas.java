
package Entity;

public class Tarefas {
    
    private int id;
    private String nomeTarefa;
    private String descricaoTarefa;
    private String dataVencimentoTarefa;
    private String usuarioTarefa;
    
    public int getId(){
        return id;
    }
    
    public void setId(int id){
        this.id = id;
    }
    
     public String getNomeTarefa(){
        return nomeTarefa;
    }
    
    public void setNomeTarefa(String nomeTarefa){
        this.nomeTarefa = nomeTarefa;
    }
    
     public String getDescricaoTarefa(){
        return descricaoTarefa;
    }
    
    public void setDescricaoTarefa(String descricaoTarefa){
        this.descricaoTarefa = descricaoTarefa;
    }
    
     public String getDataVencimentoTarefa(){
        return dataVencimentoTarefa;
    }

    public void setDataVencimentoTarefa(String dataVencimentoTarefa){
        this.dataVencimentoTarefa = dataVencimentoTarefa;
    }
    
     public String getUsuarioTarefa(){
        return usuarioTarefa;
    }
     
    public void setUsuarioTarefa(String usuarioTarefa){
        this.usuarioTarefa = usuarioTarefa;
    }
    
}

