
package Entity;

public class UsuarioLogado {
    
    private static String usuarioLogado;

    public static String getUsuarioLogado() {
        return usuarioLogado;
    }

    public static void setUsuarioLogado(String usuario) {
        usuarioLogado = usuario;
    }
}
