package Entity.DAO;

import DAO.UsuarioDAO;
import Entity.Clientes;
import GestaoDeTarefas.Cadastro;
import GestaoDeTarefas.Login;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class VerificarCadastro {

    public static String verificar(String userCadastroString, String senha1CadastroString, String senha2CadastroString) {

        //Cria uma variavel boolean para o return da funcao verificarUsuario()
        boolean usuarioValido = verificarUsuario(userCadastroString);

        //If com return para cada erro
        if (userCadastroString.equals("")) {
            return "Preencha o campo Usuário. Por favor, tente novamente.";
        }
        if (usuarioValido) {
            return "Usuário ja cadastrado. Por favor, tente novamente.";
        }
        if (senha1CadastroString.equals("")) {
            return "Preencha o campo Senha. Por favor, tente novamente.";
        }
        if (userCadastroString.length() < 6) {
            return "O nome de usuário deve conter pelo menos 6 caracteres. Por favor, tente novamente.";
        }
        if (senha1CadastroString.length() < 6) {
            return "A senha deve conter pelo menos 6 caracteres. Por favor, tente novamente.";
        }
        if (!senha1CadastroString.equals(senha2CadastroString)) {
            return "As senhas não conferem. Por favor, tente novamente.";
        }

        // Cria uma nova instância da classe Clientes
        Clientes u = new Clientes();
        
        // Define o login do usuário com a string obtida do campo de cadastro do usuário
        u.setLogin(userCadastroString);
        // Define a senha do usuário com a primeira senha obtida do campo de cadastro de senha
        u.setSenha(senha1CadastroString);

        // Cria uma nova instância de UsuarioDAO e chama o método cadastrarUsuario
        // para cadastrar o objeto 'u' (que contém o login e a senha) no banco de dados ou qualquer armazenamento usado
        new UsuarioDAO().cadastrarUsuario(u);

        return null;
    }

    public static boolean verificarUsuario(String userCadastroString) {
        //Essa calsse era verificar se o usuario inserido ja nao foi criado

        Connection conexao = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            // Estabeleça a conexão com o banco de dados (substitua as informações de conexão conforme necessário)
            conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/gestaodetarefas", "root", "");

            // Crie a consulta SQL para verificar o usuário
            String sql = "SELECT * FROM CLIENTES WHERE LOGIN = ?";
            pst = conexao.prepareStatement(sql);
            pst.setString(1, userCadastroString);

            // Execute a consulta
            rs = pst.executeQuery();

            // Verifique se o usuário existe e se a senha corresponde
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Feche os recursos
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (conexao != null) {
                    conexao.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // Em caso de erro, retorne false
        return false;
    }
}
