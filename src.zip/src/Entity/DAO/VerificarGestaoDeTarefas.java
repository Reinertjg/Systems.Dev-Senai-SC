package Entity.DAO;

import DAO.TarefaDAO;
import Entity.Tarefas;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class VerificarGestaoDeTarefas {

    public static String verificar(String nome, String descricao, String dataVencimento, String usuarioLogado) throws ParseException {
        
        
        
        //Pega a data atual do computador e loca na variavel 'dataAtual'
        LocalDate dataAtual = LocalDate.now();

        
        if (nome.equals("")) {
            return "Preencha o campo \"Nome da Tarefa\". Por favor, tente novamente.";
        }
        if (descricao.equals("")) {
            return "Preencha o campo \"Descrição\". Por favor, tente novamente.";
        }
        if (dataVencimento.equals("")) {
            return "Preencha o campo \"Data de Vencimento\". Exemplo: \"dd/MM/yy\".";
        }

        //Cria uma formatacao de data
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yy");
        // Converte a string 'dataVencimento' para um objeto LocalDate usando o formato definido por 'formato'
        LocalDate novaDataVencimento = LocalDate.parse(dataVencimento, formato);
        //Retorna uma string caso a data 'novaDataVencimento' seja anterior a data atual do computador
        if (novaDataVencimento.isBefore(dataAtual)) {
            return "Data inserida ja esta vencida. Por favor, tente novamente.";
        }
        
        String dataSQL = converterData(dataVencimento);
        
        Tarefas u = new Tarefas();
        
        u.setNomeTarefa(nome);
        u.setDescricaoTarefa(descricao);
        u.setDataVencimentoTarefa(dataSQL);
        u.setUsuarioTarefa(usuarioLogado);

        new TarefaDAO().cadastrarTarefa(u);

        return null;
    }

    public static boolean verificarUsuario(String userCadastroString) {
        Connection conexao = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            // Estabeleça a conexão com o banco de dados (substitua as informações de conexão conforme necessário)
            conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/gestaodetarefas", "root", "");

            // Crie a consulta SQL para verificar o usuário
            String sql = "SELECT * FROM CLIENTES WHERE LOGIN = ?";
            pst = conexao.prepareStatement(sql);
            pst.setString(1, userCadastroString);

            // Execute a consulta
            rs = pst.executeQuery();

            // Verifique se o usuário existe e se a senha corresponde
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Feche os recursos
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (conexao != null) {
                    conexao.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // Em caso de erro, retorne false
        return false;
    }
    
    public static String converterData(String dataVencimento) {
        String[] partes = dataVencimento.split("/");
        
        if (partes.length != 3 || partes[0].length() != 2 || partes[1].length() != 2 || partes[2].length() != 2) {
            return "Formato de data inválido";
        }

        String dia = partes[0];
        String mes = partes[1];
        String ano = partes[2];
        
        return ano + "-" + mes + "-" + dia;
    }
   
}
