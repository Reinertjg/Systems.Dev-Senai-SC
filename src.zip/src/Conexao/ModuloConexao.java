package Conexao;

import java.sql.*;

public class ModuloConexao {

    public static Connection conector() {
        java.sql.Connection conexao = null;

        String url = "jdbc:mysql://localhost:3306/gestaodetarefas";
        String driver = "com.mysql.jdbc.Driver";
        String use = "root";
        String password = "";

        try {
            Class.forName(driver);
            conexao = DriverManager.getConnection(url, use, password);
            return conexao;
        } catch (Exception e) {
            return null;
        }

    }

}
