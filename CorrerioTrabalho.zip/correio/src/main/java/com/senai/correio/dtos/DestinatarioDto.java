
package com.senai.correio.dtos;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class DestinatarioDto {
    
    @NotNull(message = "O ID não pode ser nulo")
    @Size(min = 4, max = 100, message = "O ID deve ter entre 2 e 100 caracteres")
    private String id;
    
    @NotNull(message = "O nome não pode ser nulo")
    @Size(min = 2, max = 100, message = "O nome deve ter entre 2 e 100 caracteres")
    private String nome;
    
    @NotNull(message = "O Endereco não pode ser nulo")
    private String endereco;
    
    @NotNull(message = "O Telefone não pode ser nulo")
    private String telefone;

    public DestinatarioDto() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
    
}
