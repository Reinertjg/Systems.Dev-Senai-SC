
package com.senai.correio.dtos;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class EncomendaDto {
    
    @NotNull(message = "O ID não pode ser nulo")
    @Size(min = 4, max = 100, message = "O ID deve ter entre 2 e 100 caracteres")
    private String id;
    
    @NotNull(message = "O nome não pode ser nulo")
    @Size(min = 4, max = 100, message = "O nome deve ter entre 2 e 100 caracteres")
    private String nome;
    
    @NotNull(message = "O descricao não pode ser nulo")
    @Size(min = 4, max = 100, message = "O descricao deve ter entre 2 e 100 caracteres")
    private String descricao;
    
    @NotNull(message = "O peso não pode ser nulo")
    @Size(min = 4, max = 100, message = "O peso deve ter entre 2 e 100 caracteres")
    private float peso;
    
    @NotNull(message = "O ID do destinatario não pode ser nulo")
    @Size(min = 4, max = 100, message = "O  ID do destinatario deve ter entre 2 e 100 caracteres")
    private String destinatarioId;

    public EncomendaDto() {
    }

    public String getId() {
        return id;
    }

    @NotNull
    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public String getDestinatarioId() {
        return destinatarioId;
    }

    public void setDestinatarioId(String destinatarioId) {
        this.destinatarioId = destinatarioId;
    }
    
}
